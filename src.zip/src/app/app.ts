import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { EpiList } from './epi-list/epi-list';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, EpiList],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App {
  // protected readonly title = signal('Primeira aula de angular');
  titulo = "Segurança em ação";
  subtitulo = "Aprendendo angular";
  descricao = "Este é o primeiro componente desenvolvido com angular";
  professor = "Elias Santos";
}
